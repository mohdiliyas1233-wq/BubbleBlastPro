package com.bubbleblastpro.game;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.*;

/**
 * Bubble Blast Pro - native Java Canvas prototype.
 * Portrait bubble-shooter UI inspired by the user's screenshots.
 */
public class GameView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final int[] palette = {
        Color.rgb(40, 145, 235), Color.rgb(35, 190, 112),
        Color.rgb(255, 181, 18), Color.rgb(245, 70, 137),
        Color.rgb(150, 90, 225), Color.rgb(25, 195, 205)
    };
    private final int cols = 10;
    private int rows, level = 1, score = 0, moves = 0, coins = 200;
    private int currentColor, nextColor, activeColors;
    private int[][] grid;
    private boolean home = true, paused = false, gameOver = false;
    private boolean projectile = false, rainbowNext = false, bombNext = false;
    private float ballX, ballY, ballVX, ballVY, aimX, aimY;
    private float cannonX, cannonY, radius, cell;
    private long lastTime = 0;
    private float anim = 0;
    private String toast = "";
    private long toastUntil = 0;
    private final ArrayList<Particle> particles = new ArrayList<>();
    private final float density;

    private static class Particle {
        float x,y,vx,vy,life; int color;
        Particle(float x,float y,float vx,float vy,int color) {
            this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.color=color; life=1f;
        }
    }

    public GameView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setFocusable(true);
        currentColor = random.nextInt(3);
        nextColor = random.nextInt(3);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w=getWidth(), h=getHeight();
        if (w<=0 || h<=0) return;
        long now=System.nanoTime();
        float dt=lastTime==0 ? .016f : Math.min(.035f,(now-lastTime)/1_000_000_000f);
        lastTime=now; anim += dt;
        drawBackground(c,w,h);
        if (home) drawHome(c,w,h);
        else drawGame(c,w,h,dt);
        postInvalidateOnAnimation();
    }

    private void drawBackground(Canvas c,int w,int h) {
        p.setShader(new LinearGradient(0,0,w,h,
            new int[]{Color.rgb(185,166,246),Color.rgb(255,190,222),Color.rgb(155,220,247),Color.rgb(255,215,225)},
            null,Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p); p.setShader(null);
        // soft glowing clouds / bokeh
        for(int i=0;i<18;i++) {
            float x=(float)((i*173L)%w), y=(float)((i*271L)%h);
            p.setColor(0x22FFFFFF);
            c.drawCircle(x,y,(18+(i%5)*10)*density,p);
        }
        p.setColor(0x22FFFFFF);
        for(int i=0;i<7;i++) {
            float x=(i+0.5f)*w/7f;
            c.drawCircle(x,h*.45f, w*.17f,p);
        }
    }

    private void drawHome(Canvas c,int w,int h) {
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD));
        p.setTextSize(w*.105f); p.setColor(Color.WHITE);
        c.drawText("BUBBLE",w/2f,h*.18f,p);
        p.setColor(0xFF8D48C8); c.drawText("BLAST PRO",w/2f,h*.235f,p);
        p.setTextSize(w*.052f); p.setColor(Color.WHITE);
        c.drawText("50,000 LEVELS",w/2f,h*.31f,p);
        drawPill(c,w*.09f,h*.36f,w*.91f,h*.415f,0x66FFFFFF,0xFFFFFFFF);
        p.setTextSize(w*.052f); p.setColor(Color.WHITE);
        c.drawText("🪙  "+coins+"     LEVEL "+level,w/2f,h*.395f,p);
        drawButton(c,w*.22f,h*.45f,w*.78f,h*.515f,"PLAY",0xFF36CB79,0xFF138E58);
        drawButton(c,w*.18f,h*.54f,w*.82f,h*.605f,"50,000 LEVEL MAP",0xFF56B5F4,0xFF287DBB);
        drawButton(c,w*.18f,h*.63f,w*.82f,h*.695f,"DAILY REWARDS",0xFFEF62B6,0xFFB52F83);
        drawButton(c,w*.22f,h*.72f,w*.78f,h*.785f,"SHOP",0xFF56B5F4,0xFF287DBB);
        drawButton(c,w*.22f,h*.81f,w*.78f,h*.875f,"POWER UPS",0xFFEF62B6,0xFFB52F83);
        p.setTextSize(w*.032f); p.setColor(0xDDFFFFFF);
        c.drawText("SETTINGS  •  OFFLINE PLAY",w/2f,h*.94f,p);
    }

    private void drawGame(Canvas c,int w,int h,float dt) {
        radius = w/(cols*2.18f);
        cell = radius*2.08f;
        cannonX=w/2f; cannonY=h*.855f;
        drawHud(c,w,h);
        float top=h*.13f;
        for(int r=0;r<rows;r++) for(int col=0;col<cols;col++) {
            int color=grid[r][col];
            if(color>=0) {
                float x=gridX(col), y=top+r*cell;
                drawBubble(c,x,y,radius,palette[color]);
            }
        }
        // dotted aim guide
        if(!projectile && !paused && !gameOver && aimY<cannonY) {
            float dx=aimX-cannonX, dy=aimY-cannonY;
            float len=(float)Math.hypot(dx,dy);
            if(len>1) {
                p.setColor(0xBBFFFFFF);
                for(int i=1;i<=12;i++) {
                    float t=i/14f;
                    c.drawCircle(cannonX+dx/len*w*.38f*t,cannonY+dy/len*w*.38f*t,2.1f*density,p);
                }
            }
        }
        drawCannon(c,w,h);
        if(projectile) {
            ballX += ballVX*dt; ballY += ballVY*dt;
            if(ballX<radius || ballX>w-radius) ballVX=-ballVX;
            if(ballY<h*.13f || projectileHit()) attachProjectile();
            if(projectile) drawBubble(c,ballX,ballY,radius*.94f,palette[currentColor]);
        }
        drawPowerups(c,w,h);
        updateParticles(c,dt);
        if(gameOver) {
            p.setColor(0x990A123D); c.drawRect(0,0,w,h,p);
            drawButton(c,w*.2f,h*.43f,w*.8f,h*.50f,"TRY AGAIN",0xFF35C879,0xFF138E58);
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(w*.08f);
            p.setColor(Color.WHITE); c.drawText("GAME OVER",w/2f,h*.39f,p);
        }
        if(paused) {
            p.setColor(0x990A123D); c.drawRect(0,0,w,h,p);
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(w*.09f);
            p.setColor(Color.WHITE); c.drawText("PAUSED",w/2f,h*.44f,p);
            drawButton(c,w*.22f,h*.49f,w*.78f,h*.56f,"RESUME",0xFF35C879,0xFF138E58);
            drawButton(c,w*.22f,h*.59f,w*.78f,h*.66f,"HOME",0xFF55B5F4,0xFF287DBB);
        }
        if(!toast.isEmpty() && System.currentTimeMillis()<toastUntil) {
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(w*.038f); p.setColor(Color.WHITE);
            c.drawText(toast,w/2f,h*.72f,p);
        }
    }

    private void drawHud(Canvas c,int w,int h) {
        p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD));
        p.setTextSize(w*.052f); p.setColor(Color.WHITE);
        c.drawText("LV "+level,w*.045f,h*.065f,p);
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText("★ "+score+" / "+targetScore(),w*.48f,h*.065f,p);
        p.setTextAlign(Paint.Align.RIGHT);
        c.drawText("Moves "+moves,w*.84f,h*.065f,p);
        drawButton(c,w*.87f,h*.025f,w*.98f,h*.09f,"Ⅱ",0xFFEF62B6,0xFFB52F83);
    }

    private void drawCannon(Canvas c,int w,int h) {
        // ornate gold cannon base
        p.setShader(new LinearGradient(cannonX-radius*.8f,cannonY-radius*1.7f,cannonX+radius*.8f,cannonY+radius,
            new int[]{0xFFFFF3A0,0xFFFFB51D,0xFFB95A12},null,Shader.TileMode.CLAMP));
        RectF barrel=new RectF(cannonX-radius*.72f,cannonY-radius*1.65f,cannonX+radius*.72f,cannonY+radius*.65f);
        c.drawRoundRect(barrel,radius*.5f,radius*.5f,p); p.setShader(null);
        p.setColor(0xFFFFE78A); c.drawCircle(cannonX,cannonY+radius*.45f,radius*.85f,p);
        drawBubble(c,cannonX,cannonY-radius*.15f,radius*.84f,palette[currentColor]);
        drawBubble(c,w*.79f,cannonY+radius*.55f,radius*.48f,palette[nextColor]);
    }

    private void drawPowerups(Canvas c,int w,int h) {
        String[] labels={"💣","🌈","🔥","⚡","✴","✦"};
        float y=h*.955f, bw=w*.125f, gap=w*.018f;
        float total=6*bw+5*gap, start=(w-total)/2f;
        for(int i=0;i<6;i++) {
            float x=start+i*(bw+gap);
            p.setShader(new LinearGradient(x,y-bw,x,y,0xFFFFD56C,0xFFFF9D27,Shader.TileMode.CLAMP));
            c.drawRoundRect(x,y-bw,x+bw,y,14*density,14*density,p); p.setShader(null);
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3*density);
            c.drawRoundRect(x,y-bw,x+bw,y,14*density,14*density,p); p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(bw*.53f); p.setColor(Color.WHITE);
            c.drawText(labels[i],x+bw/2f,y-bw*.31f,p);
            p.setTextSize(bw*.18f); c.drawText(i==0?"2":"1",x+bw*.82f,y-bw*.05f,p);
        }
    }

    private void drawBubble(Canvas c,float x,float y,float r,int color) {
        p.setShader(new RadialGradient(x-r*.34f,y-r*.4f,r*1.5f,
            new int[]{0xFFFFFFFF,lighten(color),color,darken(color)},
            new float[]{0f,.16f,.68f,1f},Shader.TileMode.CLAMP));
        c.drawCircle(x,y,r,p); p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1.2f,r*.045f));
        p.setColor(0x77FFFFFF); c.drawCircle(x,y,r*.96f,p); p.setStyle(Paint.Style.FILL);
        p.setColor(0xAAFFFFFF); c.drawOval(x-r*.48f,y-r*.62f,x-r*.06f,y-r*.36f,p);
    }

    private void drawButton(Canvas c,float l,float t,float r,float b,String text,int color,int shadow) {
        p.setColor(shadow); c.drawRoundRect(l,b-5*density,r,b+5*density,24*density,24*density,p);
        p.setShader(new LinearGradient(l,t,l,b,color,lighten(color),Shader.TileMode.CLAMP));
        c.drawRoundRect(l,t,r,b,24*density,24*density,p); p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4*density); p.setColor(Color.WHITE);
        c.drawRoundRect(l,t,r,b,24*density,24*density,p); p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD));
        p.setTextSize((b-t)*.43f); p.setColor(Color.WHITE);
        c.drawText(text,(l+r)/2f,(t+b)/2f-(p.ascent()+p.descent())/2f,p);
    }
    private void drawPill(Canvas c,float l,float t,float r,float b,int fill,int stroke) {
        p.setColor(fill); c.drawRoundRect(l,t,r,b,30*density,30*density,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3*density); p.setColor(stroke);
        c.drawRoundRect(l,t,r,b,30*density,30*density,p); p.setStyle(Paint.Style.FILL);
    }
    private int lighten(int color) {
        return Color.rgb(Math.min(255,Color.red(color)+55),Math.min(255,Color.green(color)+55),Math.min(255,Color.blue(color)+55));
    }
    private int darken(int color) {
        return Color.rgb(Color.red(color)/2,Color.green(color)/2,Color.blue(color)/2);
    }
    private float gridX(int col) { return getWidth()*(.055f + (col+.5f)*.89f/cols); }
    private float gridY(int row) { return getHeight()*.13f + row*cell; }
    private int targetScore() { return 500 + level*20; }
    private int colorCountForLevel() { return Math.min(6,3+(level-1)/10000); }
    private int startRowsForLevel() { return Math.min(12,4+(level-1)/4500); }
    private int movesForLevel() { return Math.max(18,42-Math.min(24,(level-1)/2000)); }

    private void startLevel() {
        home=false; paused=false; gameOver=false; projectile=false;
        activeColors=colorCountForLevel(); moves=movesForLevel();
        rows=startRowsForLevel(); grid=new int[rows][cols];
        for(int r=0;r<rows;r++) for(int col=0;col<cols;col++) {
            // Small gaps appear in later stages to change the board pattern.
            boolean gap = level>1500 && random.nextInt(100)<Math.min(22,(level-1500)/2500);
            grid[r][col]=gap ? -1 : random.nextInt(activeColors);
        }
        currentColor=random.nextInt(activeColors); nextColor=random.nextInt(activeColors);
        score=0;
    }

    private boolean projectileHit() {
        for(int r=0;r<rows;r++) for(int col=0;col<cols;col++) if(grid[r][col]>=0) {
            if(Math.hypot(ballX-gridX(col),ballY-gridY(r))<radius*1.75f) return true;
        }
        return ballY<getHeight()*.13f+radius;
    }

    private void attachProjectile() {
        projectile=false;
        int bestR=-1,bestC=-1; float best=Float.MAX_VALUE;
        for(int r=0;r<rows;r++) for(int col=0;col<cols;col++) if(grid[r][col]<0) {
            float d=(float)Math.hypot(ballX-gridX(col),ballY-gridY(r));
            if(d<best) { best=d; bestR=r; bestC=col; }
        }
        if(bestR<0 || best>radius*3.2f) {
            if(rows<15) expandGrid();
            bestR=rows-1; bestC=Math.max(0,Math.min(cols-1,Math.round((ballX/getWidth()-.055f)*cols/.89f)));
            if(grid[bestR][bestC]>=0) { gameOver=true; return; }
        }
        if(bestR>=0 && bestC>=0) {
            grid[bestR][bestC]=currentColor;
            if(bombNext) { removeAround(bestR,bestC,2); bombNext=false; }
            else if(rainbowNext) { removeColorCluster(bestR,bestC,true); rainbowNext=false; }
            else removeColorCluster(bestR,bestC,false);
            moves--;
            if(moves<=0 && !isGridEmpty()) {
                if(level%3==0) addPressureRow();
                moves=movesForLevel();
            }
            currentColor=nextColor; nextColor=random.nextInt(activeColors);
            checkWinLoss();
        }
    }

    private void expandGrid() {
        int[][] bigger=new int[rows+1][cols];
        for(int r=0;r<rows;r++) System.arraycopy(grid[r],0,bigger[r],0,cols);
        Arrays.fill(bigger[rows],-1); grid=bigger; rows++;
    }
    private ArrayList<int[]> connected(int sr,int sc,int color) {
        ArrayList<int[]> found=new ArrayList<>();
        boolean[][] seen=new boolean[rows][cols];
        ArrayDeque<int[]> q=new ArrayDeque<>(); q.add(new int[]{sr,sc}); seen[sr][sc]=true;
        while(!q.isEmpty()) {
            int[] a=q.removeFirst(); int r=a[0],c=a[1];
            if(r<0||r>=rows||c<0||c>=cols||grid[r][c]!=color) continue;
            found.add(a);
            int[][] ds={{1,0},{-1,0},{0,1},{0,-1}};
            for(int[] d:ds) { int nr=r+d[0],nc=c+d[1];
                if(nr>=0&&nr<rows&&nc>=0&&nc<cols&&!seen[nr][nc]&&grid[nr][nc]==color) {
                    seen[nr][nc]=true; q.add(new int[]{nr,nc});
                }
            }
        }
        return found;
    }
    private void removeColorCluster(int r,int c,boolean wild) {
        int color=grid[r][c];
        ArrayList<int[]> group=connected(r,c,color);
        if(wild && group.size()<3) {
            int largest=0,rr=r,cc=c;
            for(int y=0;y<rows;y++) for(int x=0;x<cols;x++) if(grid[y][x]>=0) {
                int n=connected(y,x,grid[y][x]).size();
                if(n>largest){largest=n;rr=y;cc=x;}
            }
            r=rr;c=cc;group=connected(r,c,grid[r][c]);
        }
        if(group.size()>=3) {
            for(int[] a:group) { burst(gridX(a[1]),gridY(a[0]),palette[grid[a[0]][a[1]]]); grid[a[0]][a[1]]=-1; }
            score+=group.size()*10;
            dropFloating();
        }
    }
    private void removeAround(int r,int c,int reach) {
        for(int y=Math.max(0,r-reach);y<=Math.min(rows-1,r+reach);y++)
            for(int x=Math.max(0,c-reach);x<=Math.min(cols-1,c+reach);x++)
                if(grid[y][x]>=0) { burst(gridX(x),gridY(y),palette[grid[y][x]]); grid[y][x]=-1; score+=15; }
        dropFloating();
    }
    private void dropFloating() {
        if(rows==0)return;
        boolean[][] anchored=new boolean[rows][cols];
        ArrayDeque<int[]> q=new ArrayDeque<>();
        for(int c=0;c<cols;c++) if(grid[0][c]>=0){anchored[0][c]=true;q.add(new int[]{0,c});}
        while(!q.isEmpty()) {
            int[] a=q.removeFirst();
            int[][] ds={{1,0},{-1,0},{0,1},{0,-1}};
            for(int[] d:ds){int r=a[0]+d[0],c=a[1]+d[1];
                if(r>=0&&r<rows&&c>=0&&c<cols&&!anchored[r][c]&&grid[r][c]>=0){anchored[r][c]=true;q.add(new int[]{r,c});}
            }
        }
        for(int r=0;r<rows;r++) for(int c=0;c<cols;c++)
            if(grid[r][c]>=0&&!anchored[r][c]){burst(gridX(c),gridY(r),palette[grid[r][c]]);grid[r][c]=-1;score+=20;}
    }
    private void addPressureRow() {
        if(rows>=15){gameOver=true;return;}
        int[][] bigger=new int[rows+1][cols];
        for(int r=0;r<rows;r++) System.arraycopy(grid[r],0,bigger[r+1],0,cols);
        for(int c=0;c<cols;c++) bigger[0][c]=random.nextInt(activeColors);
        grid=bigger; rows++;
        if(grid[rows-1][cols/2]>=0) gameOver=true;
    }
    private boolean isGridEmpty() {
        for(int[] row:grid) for(int v:row) if(v>=0)return false;
        return true;
    }
    private void checkWinLoss() {
        if(isGridEmpty()) {
            coins+=25+Math.min(500,level/100);
            if(level<50000) level++;
            startLevel();
            toast="LEVEL "+level+" UNLOCKED!";
            toastUntil=System.currentTimeMillis()+1800;
        }
        for(int r=0;r<rows;r++) for(int c=0;c<cols;c++)
            if(grid[r][c]>=0 && gridY(r)>getHeight()*.76f) gameOver=true;
    }
    private void burst(float x,float y,int color) {
        for(int i=0;i<9;i++) {
            double a=random.nextDouble()*Math.PI*2;
            float speed=(2+random.nextFloat()*4)*density;
            particles.add(new Particle(x,y,(float)Math.cos(a)*speed,(float)Math.sin(a)*speed,color));
        }
    }
    private void updateParticles(Canvas c,float dt) {
        Iterator<Particle> it=particles.iterator();
        while(it.hasNext()) {
            Particle q=it.next(); q.x+=q.vx; q.y+=q.vy; q.life-=dt*2.3f;
            if(q.life<=0){it.remove();continue;}
            p.setColor((Math.max(0,Math.min(255,(int)(q.life*255)))<<24)|(q.color&0x00FFFFFF));
            c.drawCircle(q.x,q.y,4*density*q.life,p);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x=e.getX(),y=e.getY(); int w=getWidth(),h=getHeight();
        if(e.getAction()==MotionEvent.ACTION_DOWN) {
            aimX=x; aimY=y; return true;
        }
        if(e.getAction()==MotionEvent.ACTION_MOVE) { aimX=x; aimY=y; return true; }
        if(e.getAction()==MotionEvent.ACTION_UP) {
            if(home) {
                if(y>h*.43f && y<h*.53f) startLevel();
                else if(y>h*.54f && y<h*.62f) { toast="50,000 LEVELS • KEEP PLAYING!"; toastUntil=System.currentTimeMillis()+1800; }
                else if(y>h*.63f && y<h*.70f) { coins+=10; toast="DAILY BONUS +10 COINS"; toastUntil=System.currentTimeMillis()+1800; }
                else if(y>h*.80f && y<h*.89f) { toast="POWER UPS: EARN COINS BY PLAYING"; toastUntil=System.currentTimeMillis()+1800; }
            } else if(paused) {
                if(y>h*.48f&&y<h*.57f) paused=false;
                else if(y>h*.58f&&y<h*.68f) { home=true; paused=false; }
            } else if(gameOver) {
                if(y>h*.40f&&y<h*.54f) startLevel();
            } else if(y<h*.10f && x>w*.85f) paused=true;
            else if(y>h*.87f) {
                int idx=(int)(x/w*6f);
                if(idx==0) bombNext=true;
                else if(idx==1) rainbowNext=true;
                else if(idx==2) { addPressureRow(); toast="FIRE POWER READY"; toastUntil=System.currentTimeMillis()+1000; }
                else if(idx==3) { moves+=5; toast="+5 MOVES"; toastUntil=System.currentTimeMillis()+1000; }
                else if(idx==4) removeAround(rows/2,cols/2,1);
                else { coins+=5; toast="+5 COINS"; toastUntil=System.currentTimeMillis()+1000; }
            } else if(y<h*.80f && y>h*.12f && !projectile) {
                float dx=x-cannonX,dy=y-cannonY,len=(float)Math.hypot(dx,dy);
                if(dy<0&&len>1) {
                    ballX=cannonX; ballY=cannonY-radius*.5f;
                    ballVX=dx/len*w*.92f; ballVY=dy/len*w*.92f;
                    projectile=true;
                }
            }
            return true;
        }
        return true;
    }
}
