BUBBLE BLAST PRO — JAVA ANDROID PROJECT

यह उपयोगकर्ता के दिए हुए Bubble Shooter स्क्रीनशॉट से प्रेरित एक native Java Canvas prototype है।

प्रोजेक्ट में:
- Portrait home screen और gameplay screen
- Glossy gradient bubbles, cannon, aim guide और particle effects
- Tap/drag aim और release पर bubble shoot
- Connected same-colour bubble group match (3 या अधिक)
- Score, moves, coins, pause, retry और power-up buttons
- Level counter 1 से 50,000 तक
- आगे के स्तरों पर अधिक bubble colours, अधिक starting rows, कम moves और board gaps

महत्वपूर्ण सीमाएँ:
- यह पहला playable prototype है; screenshot का exact clone नहीं है।
- Background, bubble art और UI अभी Canvas से draw होते हैं; external artwork/audio शामिल नहीं।
- 50,000 स्तरों के लिए procedural difficulty scaling है, पर हर स्तर की manual level design नहीं।
- Power-up buttons के कुछ effects prototype स्तर के हैं; balance/animation/audio आगे polish करने होंगे।
- Device पर APK/AAB build और gameplay test इस environment में नहीं किया गया है।

Build:
1. ZIP extract करें।
2. Android Studio या compatible Android Gradle IDE में project folder खोलें।
3. Gradle sync करें और device/emulator पर Run करें।
4. Release से पहले विभिन्न screen sizes, memory, collision, level progression और performance टेस्ट करें।
